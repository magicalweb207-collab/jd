import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

// ═══════════════════════════════════════════
// JD Social — Live Streaming Screen
// Agora RTC / WebRTC দিয়ে লাইভ স্ট্রিমিং
// ═══════════════════════════════════════════

class LiveStreamScreen extends StatefulWidget {
  final bool isHost; // true = broadcaster, false = viewer
  final String streamId;
  final String hostName;

  const LiveStreamScreen({
    super.key,
    required this.isHost,
    required this.streamId,
    required this.hostName,
  });

  @override
  State<LiveStreamScreen> createState() => _LiveStreamScreenState();
}

class _LiveStreamScreenState extends State<LiveStreamScreen> {
  bool _isMicOn   = true;
  bool _isCamOn   = true;
  bool _isBeauty  = false;
  int  _viewerCount = 0;
  int  _giftCount   = 0;
  double _earnings  = 0.0;

  final List<_LiveComment> _comments = [
    _LiveComment('করিম ভাই', 'অনেক সুন্দর! 🔥', AppTheme.accentBlue),
    _LiveComment('মিতা আপা', 'আমি এখন দেখছি ❤️', AppTheme.accentGreen),
    _LiveComment('নাফিসা', 'বাহ! কী দারুণ', AppTheme.accentCyan),
  ];

  final _commentCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _simulateViewers();
  }

  void _simulateViewers() {
    // In production: Agora SDK user-join callbacks
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) setState(() { _viewerCount = 47; _earnings = 3.20; });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildVideoArea(),
          _buildTopBar(),
          _buildBottomControls(),
          _buildCommentFeed(),
          _buildGiftButton(),
        ],
      ),
    );
  }

  // Video / Camera preview area
  Widget _buildVideoArea() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0A0A2E), Color(0xFF001A0A)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Center(
        child: widget.isHost
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _isCamOn ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                    color: Colors.white24, size: 80,
                  ),
                  const SizedBox(height: 12),
                  const Text('ক্যামেরা লাইভ', style: TextStyle(
                    color: Colors.white30, fontFamily: 'HindSiliguri',
                  )),
                  const Text('(Agora SDK দিয়ে ভিডিও স্ট্রিম হবে)',
                    style: TextStyle(color: Colors.white20, fontSize: 12)),
                ],
              )
            : const Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.live_tv, color: Colors.white24, size: 80),
                  SizedBox(height: 12),
                  Text('লাইভ দেখছেন...', style: TextStyle(
                    color: Colors.white30, fontFamily: 'HindSiliguri',
                  )),
                ],
              ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Positioned(
      top: 0, left: 0, right: 0,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              // Host info
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircleAvatar(
                      radius: 14,
                      backgroundColor: AppTheme.accentBlue.withOpacity(0.3),
                      child: Text(widget.hostName[0], style: const TextStyle(
                        color: AppTheme.accentBlue, fontSize: 12,
                        fontWeight: FontWeight.w700,
                      )),
                    ),
                    const SizedBox(width: 8),
                    Text(widget.hostName, style: const TextStyle(
                      color: Colors.white, fontSize: 13,
                      fontWeight: FontWeight.w600, fontFamily: 'HindSiliguri',
                    )),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.circle, color: Colors.white, size: 6),
                          SizedBox(width: 4),
                          Text('লাইভ', style: TextStyle(
                            color: Colors.white, fontSize: 11,
                            fontWeight: FontWeight.w700, fontFamily: 'HindSiliguri',
                          )),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const Spacer(),

              // Viewer count
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.remove_red_eye_outlined, color: Colors.white70, size: 14),
                    const SizedBox(width: 5),
                    Text('$_viewerCount', style: const TextStyle(
                      color: Colors.white, fontSize: 13, fontFamily: 'Exo2',
                    )),
                  ],
                ),
              ),
              const SizedBox(width: 8),

              // Close
              GestureDetector(
                onTap: () => _confirmEndLive(),
                child: Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.close, color: Colors.white70, size: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCommentFeed() {
    return Positioned(
      bottom: 150, left: 12, right: 80,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: _comments.takeLast(5).map((c) => _commentBubble(c)).toList(),
      ),
    );
  }

  Widget _commentBubble(_LiveComment c) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.5),
        borderRadius: BorderRadius.circular(20),
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13),
          children: [
            TextSpan(text: '${c.name}  ', style: TextStyle(
              color: c.color, fontWeight: FontWeight.w700,
            )),
            TextSpan(text: c.text, style: const TextStyle(color: Colors.white)),
          ],
        ),
      ),
    );
  }

  Widget _buildGiftButton() {
    return Positioned(
      bottom: 200, right: 12,
      child: Column(
        children: [
          GestureDetector(
            onTap: _sendGift,
            child: Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Colors.pink, Colors.redAccent],
                ),
                borderRadius: BorderRadius.circular(25),
                boxShadow: [
                  BoxShadow(color: Colors.pink.withOpacity(0.5), blurRadius: 15),
                ],
              ),
              child: const Icon(Icons.card_giftcard, color: Colors.white, size: 24),
            ),
          ),
          if (_giftCount > 0) ...[
            const SizedBox(height: 4),
            Text('$_giftCount', style: const TextStyle(
              color: Colors.pink, fontSize: 12,
              fontWeight: FontWeight.w700, fontFamily: 'Exo2',
            )),
          ],
        ],
      ),
    );
  }

  Widget _buildBottomControls() {
    return Positioned(
      bottom: 0, left: 0, right: 0,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
            colors: [Colors.black.withOpacity(0.8), Colors.transparent],
          ),
        ),
        child: Column(
          children: [
            // Earnings bar (host only)
            if (widget.isHost)
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.monetization_on, color: AppTheme.accentGreen, size: 16),
                    const SizedBox(width: 6),
                    Text('লাইভ আয়: ৳${_earnings.toStringAsFixed(2)}',
                      style: const TextStyle(
                        color: AppTheme.accentGreen, fontSize: 13,
                        fontWeight: FontWeight.w600, fontFamily: 'HindSiliguri',
                      )),
                  ],
                ),
              ),

            Row(
              children: [
                // Comment input
                Expanded(
                  child: Container(
                    height: 42,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(21),
                    ),
                    child: TextField(
                      controller: _commentCtrl,
                      style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'HindSiliguri'),
                      decoration: const InputDecoration(
                        hintText: 'কমেন্ট করুন...',
                        hintStyle: TextStyle(color: Colors.white38),
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        border: InputBorder.none,
                      ),
                      onSubmitted: _sendComment,
                    ),
                  ),
                ),
                const SizedBox(width: 10),

                // Mic toggle (host only)
                if (widget.isHost) ...[
                  _controlBtn(
                    _isMicOn ? Icons.mic : Icons.mic_off,
                    _isMicOn ? Colors.white70 : Colors.redAccent,
                    () => setState(() => _isMicOn = !_isMicOn),
                  ),
                  const SizedBox(width: 8),
                  _controlBtn(
                    _isCamOn ? Icons.videocam : Icons.videocam_off,
                    _isCamOn ? Colors.white70 : Colors.redAccent,
                    () => setState(() => _isCamOn = !_isCamOn),
                  ),
                ] else ...[
                  _controlBtn(Icons.card_giftcard, Colors.pink, _sendGift),
                  const SizedBox(width: 8),
                  _controlBtn(Icons.favorite, Colors.redAccent, () {}),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _controlBtn(IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(21),
        ),
        child: Icon(icon, color: color, size: 22),
      ),
    );
  }

  void _sendComment(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      _comments.add(_LiveComment('আপনি', text.trim(), Colors.white));
      _commentCtrl.clear();
    });
  }

  void _sendGift() {
    setState(() {
      _giftCount++;
      _earnings += 5.0; // ৳5 per gift, 90% to host
    });
  }

  void _confirmEndLive() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text('লাইভ শেষ করবেন?', style: TextStyle(
          fontFamily: 'HindSiliguri', color: AppTheme.textPrimary,
        )),
        content: Text(
          'আপনি ৳${_earnings.toStringAsFixed(2)} আয় করেছেন',
          style: const TextStyle(fontFamily: 'HindSiliguri', color: AppTheme.textMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('না', style: TextStyle(fontFamily: 'HindSiliguri')),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('লাইভ শেষ', style: TextStyle(fontFamily: 'HindSiliguri')),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _commentCtrl.dispose();
    super.dispose();
  }
}

class _LiveComment {
  final String name, text;
  final Color color;
  _LiveComment(this.name, this.text, this.color);
}

extension ListTakeLast<T> on List<T> {
  List<T> takeLast(int n) => length <= n ? this : sublist(length - n);
}
