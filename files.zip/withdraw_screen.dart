import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../theme/app_theme.dart';

// ═══════════════════════════════════════════
// JD Social — bKash / Nagad Payment Gateway
// ৳ উত্তোলন সিস্টেম
// ═══════════════════════════════════════════

enum PaymentMethod { bkash, nagad, rocket, bankTransfer }

class WithdrawScreen extends StatefulWidget {
  final double availableBalance;
  const WithdrawScreen({super.key, required this.availableBalance});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  PaymentMethod _selectedMethod = PaymentMethod.bkash;
  final _amountCtrl  = TextEditingController();
  final _accountCtrl = TextEditingController();
  bool _isProcessing = false;
  String? _txId;

  static const double MIN_WITHDRAW = 100.0;
  static const double MAX_WITHDRAW = 25000.0;

  final Map<PaymentMethod, _MethodInfo> _methods = {
    PaymentMethod.bkash: _MethodInfo('bKash', '01XXXXXXXXX', const Color(0xFFE2136E), Icons.phone_android),
    PaymentMethod.nagad: _MethodInfo('Nagad', '01XXXXXXXXX', const Color(0xFFF6A623), Icons.account_balance_wallet),
    PaymentMethod.rocket: _MethodInfo('Rocket', '01XXXXXXXXX', const Color(0xFF8B1A8B), Icons.rocket_launch),
    PaymentMethod.bankTransfer: _MethodInfo('ব্যাংক ট্রান্সফার', 'অ্যাকাউন্ট নম্বর', Colors.teal, Icons.account_balance),
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        title: const Text('টাকা উত্তোলন', style: TextStyle(fontFamily: 'HindSiliguri')),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBalanceCard(),
            const SizedBox(height: 24),
            _sectionLabel('পেমেন্ট মেথড বেছে নিন'),
            const SizedBox(height: 12),
            _buildMethodSelector(),
            const SizedBox(height: 24),
            _sectionLabel('পরিমাণ (৳)'),
            const SizedBox(height: 10),
            _buildAmountField(),
            const SizedBox(height: 8),
            _buildQuickAmounts(),
            const SizedBox(height: 20),
            _sectionLabel('${_methods[_selectedMethod]!.name} নম্বর'),
            const SizedBox(height: 10),
            _buildAccountField(),
            const SizedBox(height: 28),
            _buildFeeInfo(),
            const SizedBox(height: 20),
            _buildWithdrawButton(),
            if (_txId != null) ...[
              const SizedBox(height: 20),
              _buildSuccessCard(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBalanceCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.accentGreen.withOpacity(0.15), AppTheme.accentBlue.withOpacity(0.08)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.accentGreen.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.account_balance_wallet, color: AppTheme.accentGreen, size: 32),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('উপলব্ধ ব্যালেন্স', style: TextStyle(
                color: AppTheme.textMuted, fontSize: 13, fontFamily: 'HindSiliguri',
              )),
              Text('৳ ${widget.availableBalance.toStringAsFixed(2)}',
                style: const TextStyle(
                  color: AppTheme.accentGreen, fontSize: 28,
                  fontWeight: FontWeight.w900, fontFamily: 'Exo2',
                )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMethodSelector() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 2.8,
      children: _methods.entries.map((e) {
        final isSelected = _selectedMethod == e.key;
        final info = e.value;
        return GestureDetector(
          onTap: () => setState(() => _selectedMethod = e.key),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: isSelected ? info.color.withOpacity(0.15) : AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? info.color : Colors.white.withOpacity(0.08),
                width: isSelected ? 1.5 : 0.5,
              ),
            ),
            child: Row(
              children: [
                Icon(info.icon, color: isSelected ? info.color : AppTheme.textMuted, size: 20),
                const SizedBox(width: 8),
                Text(info.name, style: TextStyle(
                  color: isSelected ? info.color : AppTheme.textMuted,
                  fontSize: 13, fontWeight: FontWeight.w600,
                  fontFamily: 'HindSiliguri',
                )),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildAmountField() {
    return TextField(
      controller: _amountCtrl,
      keyboardType: TextInputType.number,
      style: const TextStyle(
        color: AppTheme.textPrimary, fontSize: 22,
        fontWeight: FontWeight.w700, fontFamily: 'Exo2',
      ),
      decoration: InputDecoration(
        prefixText: '৳ ',
        prefixStyle: const TextStyle(color: AppTheme.accentGreen, fontSize: 22, fontWeight: FontWeight.w700),
        hintText: '০',
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 22),
        suffixText: 'BDT',
        suffixStyle: const TextStyle(color: AppTheme.textMuted, fontSize: 14),
      ),
      onChanged: (_) => setState(() {}),
    );
  }

  Widget _buildQuickAmounts() {
    final amounts = [200.0, 500.0, 1000.0, 2500.0];
    return Row(
      children: amounts.map((a) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: GestureDetector(
            onTap: () {
              final capped = a > widget.availableBalance ? widget.availableBalance : a;
              _amountCtrl.text = capped.toStringAsFixed(0);
              setState(() {});
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.bgCard2,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.white.withOpacity(0.06)),
              ),
              child: Center(child: Text('৳${a.toStringAsFixed(0)}', style: const TextStyle(
                color: AppTheme.textMuted, fontSize: 12, fontFamily: 'HindSiliguri',
              ))),
            ),
          ),
        ),
      )).toList(),
    );
  }

  Widget _buildAccountField() {
    return TextField(
      controller: _accountCtrl,
      keyboardType: TextInputType.phone,
      style: const TextStyle(color: AppTheme.textPrimary, fontFamily: 'HindSiliguri'),
      decoration: InputDecoration(
        hintText: _methods[_selectedMethod]!.placeholder,
        prefixIcon: Icon(_methods[_selectedMethod]!.icon,
            color: _methods[_selectedMethod]!.color, size: 20),
      ),
    );
  }

  Widget _buildFeeInfo() {
    final amount = double.tryParse(_amountCtrl.text) ?? 0;
    final fee = amount * 0.015; // 1.5% fee
    final youGet = amount - fee;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        children: [
          _feeRow('উত্তোলনের পরিমাণ', '৳ ${amount.toStringAsFixed(2)}', AppTheme.textPrimary),
          _feeRow('সার্ভিস চার্জ (১.৫%)', '- ৳ ${fee.toStringAsFixed(2)}', Colors.orange.shade300),
          Divider(color: Colors.white.withOpacity(0.08), height: 20),
          _feeRow('আপনি পাবেন', '৳ ${youGet.toStringAsFixed(2)}', AppTheme.accentGreen, bold: true),
        ],
      ),
    );
  }

  Widget _feeRow(String label, String value, Color valueColor, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(
            color: AppTheme.textMuted, fontSize: 13, fontFamily: 'HindSiliguri',
          )),
          Text(value, style: TextStyle(
            color: valueColor, fontSize: 13, fontFamily: 'Exo2',
            fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
          )),
        ],
      ),
    );
  }

  Widget _buildWithdrawButton() {
    final amount = double.tryParse(_amountCtrl.text) ?? 0;
    final isValid = amount >= MIN_WITHDRAW &&
        amount <= widget.availableBalance &&
        _accountCtrl.text.isNotEmpty;

    return GestureDetector(
      onTap: isValid && !_isProcessing ? _processWithdrawal : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity, height: 54,
        decoration: BoxDecoration(
          gradient: isValid
              ? const LinearGradient(colors: [AppTheme.accentGreen, Color(0xFF28a745)])
              : null,
          color: isValid ? null : Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Center(
          child: _isProcessing
              ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
              : Text(
                  amount < MIN_WITHDRAW && amount > 0
                      ? 'সর্বনিম্ন ৳$MIN_WITHDRAW'
                      : 'উত্তোলন করুন',
                  style: TextStyle(
                    color: isValid ? Colors.white : AppTheme.textMuted,
                    fontSize: 16, fontWeight: FontWeight.w700,
                    fontFamily: 'HindSiliguri',
                  ),
                ),
        ),
      ),
    );
  }

  Widget _buildSuccessCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.accentGreen.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.accentGreen.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          const Icon(Icons.check_circle, color: AppTheme.accentGreen, size: 40),
          const SizedBox(height: 10),
          const Text('উত্তোলন সফল হয়েছে! ✅', style: TextStyle(
            color: AppTheme.accentGreen, fontSize: 16,
            fontWeight: FontWeight.w700, fontFamily: 'HindSiliguri',
          )),
          const SizedBox(height: 6),
          Text('ট্রানজেকশন ID: $_txId', style: const TextStyle(
            color: AppTheme.textMuted, fontSize: 12, fontFamily: 'Exo2',
          )),
          const SizedBox(height: 4),
          const Text('৩-৫ মিনিটের মধ্যে টাকা পাবেন', style: TextStyle(
            color: AppTheme.textMuted, fontSize: 12, fontFamily: 'HindSiliguri',
          )),
        ],
      ),
    );
  }

  Future<void> _processWithdrawal() async {
    setState(() => _isProcessing = true);
    try {
      // Call Firebase Cloud Function
      final response = await http.post(
        Uri.parse('https://YOUR_REGION-YOUR_PROJECT.cloudfunctions.net/requestWithdrawal'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'amount': double.parse(_amountCtrl.text),
          'method': _selectedMethod.name,
          'accountNumber': _accountCtrl.text.trim(),
        }),
      );
      final data = jsonDecode(response.body);
      if (data['success'] == true) {
        setState(() => _txId = data['withdrawalId']);
      } else {
        _showError(data['error'] ?? 'উত্তোলন ব্যর্থ হয়েছে');
      }
    } catch (e) {
      _showError('নেটওয়ার্ক সমস্যা, আবার চেষ্টা করুন');
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Widget _sectionLabel(String text) {
    return Text(text, style: const TextStyle(
      color: AppTheme.textPrimary, fontSize: 14,
      fontWeight: FontWeight.w600, fontFamily: 'HindSiliguri',
    ));
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'HindSiliguri')),
      backgroundColor: AppTheme.bgCard2,
    ));
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _accountCtrl.dispose();
    super.dispose();
  }
}

class _MethodInfo {
  final String name, placeholder;
  final Color color;
  final IconData icon;
  _MethodInfo(this.name, this.placeholder, this.color, this.icon);
}
