import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../theme/app_theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;

  // Login fields
  final _loginEmailCtrl = TextEditingController();
  final _loginPassCtrl  = TextEditingController();

  // Signup fields
  final _signupNameCtrl  = TextEditingController();
  final _signupEmailCtrl = TextEditingController();
  final _signupPassCtrl  = TextEditingController();
  final _signupPhoneCtrl = TextEditingController();

  bool _obscureLogin  = true;
  bool _obscureSignup = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: Stack(
        children: [
          // Glow BG
          Positioned(top: -120, left: -80,
            child: _glowCircle(AppTheme.accentBlue, 350)),
          Positioned(bottom: -100, right: -80,
            child: _glowCircle(AppTheme.accentGreen, 280)),

          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  const SizedBox(height: 48),
                  _buildLogo(),
                  const SizedBox(height: 40),
                  _buildTabBar(),
                  const SizedBox(height: 30),
                  SizedBox(
                    height: 480,
                    child: TabBarView(
                      controller: _tabController,
                      children: [_buildLoginForm(), _buildSignupForm()],
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildSocialDivider(),
                  const SizedBox(height: 16),
                  _buildPhoneLogin(),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _glowCircle(Color color, double size) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: [
          color.withOpacity(0.15), Colors.transparent,
        ]),
      ),
    );
  }

  Widget _buildLogo() {
    return Column(
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.accentBlue, AppTheme.accentCyan],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(color: AppTheme.accentBlue.withOpacity(0.5),
                  blurRadius: 30, spreadRadius: 2),
            ],
          ),
          child: const Center(child: Text('JD', style: TextStyle(
            color: Colors.white, fontSize: 34,
            fontWeight: FontWeight.w900, fontFamily: 'Exo2',
          ))),
        ),
        const SizedBox(height: 16),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            colors: [AppTheme.accentBlue, AppTheme.accentCyan],
          ).createShader(b),
          child: const Text('JD Social', style: TextStyle(
            color: Colors.white, fontSize: 30,
            fontWeight: FontWeight.w900, fontFamily: 'Exo2',
          )),
        ),
        const SizedBox(height: 6),
        const Text('কথা বলো · দেখো · আয় করো', style: TextStyle(
          color: AppTheme.textMuted, fontSize: 13,
          letterSpacing: 0.8, fontFamily: 'HindSiliguri',
        )),
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppTheme.accentBlue, AppTheme.accentCyan],
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: AppTheme.textMuted,
        labelStyle: const TextStyle(
          fontWeight: FontWeight.w600, fontSize: 15,
          fontFamily: 'HindSiliguri',
        ),
        dividerColor: Colors.transparent,
        tabs: const [
          Tab(text: 'লগইন'),
          Tab(text: 'নিবন্ধন'),
        ],
      ),
    );
  }

  Widget _buildLoginForm() {
    return Column(
      children: [
        _inputField(
          controller: _loginEmailCtrl,
          hint: 'ইমেইল বা ফোন নম্বর',
          icon: Icons.email_outlined,
        ),
        const SizedBox(height: 14),
        _inputField(
          controller: _loginPassCtrl,
          hint: 'পাসওয়ার্ড',
          icon: Icons.lock_outline,
          obscure: _obscureLogin,
          toggleObscure: () => setState(() => _obscureLogin = !_obscureLogin),
        ),
        const SizedBox(height: 10),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: _forgotPassword,
            child: const Text('পাসওয়ার্ড ভুলে গেছেন?', style: TextStyle(
              color: AppTheme.accentBlue, fontFamily: 'HindSiliguri',
            )),
          ),
        ),
        const SizedBox(height: 10),
        _gradientButton('লগইন করুন', _login),
        const SizedBox(height: 16),
        _buildRevenueReminder(),
      ],
    );
  }

  Widget _buildSignupForm() {
    return Column(
      children: [
        _inputField(controller: _signupNameCtrl, hint: 'আপনার নাম', icon: Icons.person_outline),
        const SizedBox(height: 12),
        _inputField(controller: _signupPhoneCtrl, hint: 'মোবাইল নম্বর', icon: Icons.phone_outlined, keyboardType: TextInputType.phone),
        const SizedBox(height: 12),
        _inputField(controller: _signupEmailCtrl, hint: 'ইমেইল (ঐচ্ছিক)', icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress),
        const SizedBox(height: 12),
        _inputField(
          controller: _signupPassCtrl,
          hint: 'পাসওয়ার্ড',
          icon: Icons.lock_outline,
          obscure: _obscureSignup,
          toggleObscure: () => setState(() => _obscureSignup = !_obscureSignup),
        ),
        const SizedBox(height: 20),
        _gradientButton('অ্যাকাউন্ট তৈরি করুন', _signup),
      ],
    );
  }

  Widget _inputField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    VoidCallback? toggleObscure,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      style: const TextStyle(color: AppTheme.textPrimary, fontFamily: 'HindSiliguri'),
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: AppTheme.textMuted, size: 20),
        suffixIcon: toggleObscure != null
            ? IconButton(
                icon: Icon(
                  obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                  color: AppTheme.textMuted, size: 20,
                ),
                onPressed: toggleObscure,
              )
            : null,
      ),
    );
  }

  Widget _gradientButton(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: _isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppTheme.accentBlue, AppTheme.accentCyan],
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(color: AppTheme.accentBlue.withOpacity(0.4),
                blurRadius: 20, offset: const Offset(0, 6)),
          ],
        ),
        child: Center(
          child: _isLoading
              ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
              : Text(label, style: const TextStyle(
                  color: Colors.white, fontSize: 16,
                  fontWeight: FontWeight.w700, fontFamily: 'HindSiliguri',
                )),
        ),
      ),
    );
  }

  Widget _buildRevenueReminder() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.accentGreen.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.accentGreen.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.monetization_on, color: AppTheme.accentGreen, size: 20),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('লগইন করুন এবং আয়ের ৯০% পান!',
              style: TextStyle(
                color: AppTheme.accentGreen, fontSize: 13,
                fontFamily: 'HindSiliguri', fontWeight: FontWeight.w500,
              )),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialDivider() {
    return Row(
      children: [
        Expanded(child: Divider(color: Colors.white.withOpacity(0.1))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text('অথবা', style: TextStyle(
            color: AppTheme.textMuted, fontFamily: 'HindSiliguri',
          )),
        ),
        Expanded(child: Divider(color: Colors.white.withOpacity(0.1))),
      ],
    );
  }

  Widget _buildPhoneLogin() {
    return OutlinedButton.icon(
      onPressed: () {},
      icon: const Icon(Icons.phone_android, size: 20),
      label: const Text('OTP দিয়ে লগইন করুন', style: TextStyle(fontFamily: 'HindSiliguri')),
      style: OutlinedButton.styleFrom(
        foregroundColor: AppTheme.textPrimary,
        side: BorderSide(color: Colors.white.withOpacity(0.15)),
        minimumSize: const Size(double.infinity, 50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Future<void> _login() async {
    setState(() => _isLoading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _loginEmailCtrl.text.trim(),
        password: _loginPassCtrl.text.trim(),
      );
      if (mounted) Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseAuthException catch (e) {
      _showError(e.message ?? 'লগইন ব্যর্থ হয়েছে');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _signup() async {
    setState(() => _isLoading = true);
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _signupEmailCtrl.text.trim(),
        password: _signupPassCtrl.text.trim(),
      );
      if (mounted) Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseAuthException catch (e) {
      _showError(e.message ?? 'নিবন্ধন ব্যর্থ হয়েছে');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _forgotPassword() async {
    if (_loginEmailCtrl.text.isEmpty) {
      _showError('আপনার ইমেইল লিখুন');
      return;
    }
    await FirebaseAuth.instance.sendPasswordResetEmail(
      email: _loginEmailCtrl.text.trim(),
    );
    _showError('পাসওয়ার্ড রিসেট ইমেইল পাঠানো হয়েছে ✅');
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'HindSiliguri')),
      backgroundColor: AppTheme.bgCard2,
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  void dispose() {
    _tabController.dispose();
    _loginEmailCtrl.dispose();
    _loginPassCtrl.dispose();
    _signupNameCtrl.dispose();
    _signupEmailCtrl.dispose();
    _signupPassCtrl.dispose();
    _signupPhoneCtrl.dispose();
    super.dispose();
  }
}
